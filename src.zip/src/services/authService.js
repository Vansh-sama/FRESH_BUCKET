import api from './api';

export const loginApi = async userData => {
  const response = await api.post(
    '/auth/login',
    userData,
  );

  return response.data;
};

export const registerApi = async userData => {
  const response = await api.post(
    '/auth/register',
    userData,
  );

  return response.data;
};

export const getProfileApi = async token => {
  const response = await api.get(
    '/auth/profile',
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    },
  );

  return response.data;
};